# Data Science Multi-User Environment
Refer to the following sections for installation and maintenance operations:
* [Deployment](#Deployment)
* [Post-Deployment](#Post-Deployment)
* [Maintenance](#Maintenance)
* [Uninstallation](#Uninstallation)

## Deployment
Refer to the following sections for more information regarding deployment:
* [Performing a Deployment](#Performing-a-Deployment)
* [Advanced Deployment Configuration](#Advanced-Deployment-Configuration)

### Performing a Deployment
The following describes how to deploy this VM configuration.


#### Deploying from [Azure Portal Cloud Shell Console](https://docs.microsoft.com/en-us/azure/cloud-shell/quickstart-powershell) (Recommended)

1.  Download execution scripts to cloud shell storage using the cloud shell PowerShell console.

```ps
Invoke-WebRequest -Uri "https://dsarchitectures3f4g5.blob.core.windows.net/dstemplates/base-template-windows-v2.0.zip" -OutFile "base-template.zip"
```

2. Extract execution scripts zip file:

```ps
Expand-Archive -LiteralPath ./base-template.zip -DestinationPath ./base-template
```

3. Change to execution directory:

```ps
cd ./base-template/config
```

4. Run the following command with the parameter placeholders replaced with the appropriate values for your environment:

```ps
.\deploy.ps1 -Subscription "subscriptionId" -Tenant "TenantId" -Prefix "uniquePrefix" -Random "randomValue" -ResourceGroup "resourceGroupName" -VMSize "VMSize" -location "location"
```
***Note:** When using the Azure Cloud Shell you need to add your current IP Address to the network security group (NSG) of the VM to access the resources.*

#### Deploying from a windows machine

1.  Download execution scripts.

```ps
Invoke-WebRequest -Uri "https://dsarchitectures3f4g5.blob.core.windows.net/dstemplates/base-template-windows-v2.0.zip" -OutFile "base-template.zip"
```

2. Extract execution scripts zip file:

```ps
Expand-Archive -LiteralPath ./base-template.zip -DestinationPath ./base-template
```

3. Change to execution directory:

```ps
cd ./base-template/config
```

4. Run the following command to allow unrestricted execution to the powershell script

```ps
 Set-ExecutionPolicy -ExecutionPolicy Unrestricted -Scope Process
```

5. Run the following command with the parameter placeholders replaced with the appropriate values for your environment:

```ps
.\deploy.ps1 -Subscription "subscriptionId" -Tenant "TenantId" -Prefix "uniquePrefix" -Random "randomValue" -ResourceGroup "resourceGroupName" -VMSize "VMSize" -location "location"
```

***Note:** If you have additional configuration needs please refer to the [Advanced Configuration](#Advanced-Deployment-Configuration) section.*

### Parameters (deploy.ps1)

|Required|Name|Description|Default|
|-|-|-|-|
|✓|Subscription|The target Azure Subscription id.|*none*|
|✓|Tenant|Azure Active Directory Tenant Id|*none*|
|✓|Prefix|A unique prefix for resources.|*none*|
|✓|adminPassword|A unique 12 caharacter long password. Combine uppercase, lowercase, numbers adn a special character such as ! $ etc.|*none*|
||Random|A random value to help ensure uniqueness of resource names.|A pseudo-random selection of 5 characters.|
||adminObjectId|Active Directory Object Id of user to be added as the default admin of the VM|*none*|
||ResourceGroup|The target Azure Resource Group name.|{Prefix}-{Random}-jhub|
||VMSize|Azure VM Sku|Standard_NC6|
||location|Location of the resources|eastus|
||SkipArm|A switch specifying to skip the ARM deployment.|N/A|
||SkipCert|A switch specifying to skip requesting an SSL certificate from Let's Encrypt.|N/A|
||SkipAuth|Skip authorization.|N/A|
||Uninstall|A switch specifying to uninstall a deployment. **You must specify the -Random parameter with the correct value for your environment for this mode**.|N/A|

<table>
    <tr>
        <td style='background-color: dodgerblue; color: white;'>
            Example
        </td>
        <td>
            <code>
                .\deploy.ps1 -Subscription "00000000-0000-0000-0000-000000000000" -Tenant "00000000-0000-0000-0000-000000000000" -Prefix cdr -Random dev01 -ResourceGroup "test-deploy-ru" -VMSize "Standard_NC6" -location westus2
            </code>
        </td>
    </tr>
</table>

4. That's it! Now you should be able to connect to your VM using Azure Bastion

### Advanced Deployment Configuration
For advanced configuration scenarios such as but not limited to specifying an existing storage account in the target resource group edit the [azuredeploy.parameters.template.json](../config/arm/azuredeploy.parameters.template.json) file before running the installation script.

The following details the effect each parameter has on the deployed solution:
|Name|Description|
|-|-|
|storageAccount_name|The name for the storage account resource. If you want to use an existing storage account in the target resource group make sure this parameter reflects the name of the existing resource.|
|container_name|The name of the common file container. **You should not change this.**|


## Maintenance
The following provides detailed for the following maintenance tasks:

1. [Add a new VM User](#Add-a-new-VM-user)
1. [Uninstall resources](#Uninstall-resources)


### Add a new VM user

1. Add the user to the **Reader** role for the VM resource and the Azure Bastion resource in the Azure portal.
2. Connect to the VM and add a new user account

## Uninstallation
Perform the following steps to uninstall resources:

1. Make note of the *prefix* and *random value* used when installing your resources. This can be determined by any resource name.

#### Example:
```ps
cdrnbepywusjhubvm01
[ ][   ]
 ^   ^
 |   |
 |   +--- Random value
 |
 +------- Prefix
```

2. It is recommended you follow the steps to [revoke the SSL certificate](#Revoke-SSL-certificate) if you will no longer be using it. If you are migrating to a new resource, make sure and copy the SSL certificate and private key off of the VM before uninstalling.
3. Navigate to the cloned repository and run the following command:

```ps
.\deploy.ps1 -Subscription {subscriptionId} -Tenant {TenantId} -ResourceGroup {resourceGroupName} -Prefix {prefixValue} -Random {randomValue} -Uninstall
```

Refer to the previous [parameters](#Parameters-deployps1) for more information regarding the parameters.

The script will remove all of the resources in the resource group and the application registration.