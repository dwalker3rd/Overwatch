## Copyright (c) Microsoft Corporation. All rights reserved.
## Licensed under the MIT License.
Param (
    [Parameter(Mandatory=$true)][string]$Subscription,
    [Parameter(Mandatory=$true)][string]$Tenant,
    [Parameter(Mandatory=$true)][string]$ResourceGroup,
    [Parameter(Mandatory=$true)][string]$Prefix,
    [Parameter(Mandatory=$true)][string]$Random,
    [Parameter(Mandatory=$false)][string]$AdminObjectId,
    [Parameter(Mandatory=$false)][string]$ArmTemplateFilePath = "./arm/azuredeploy.template.json",
    [Parameter(Mandatory=$false)][string]$ArmTemplateParametersFilePath = "./arm/azuredeploy.parameters.template.json",
    [Parameter(Mandatory=$false)][string]$ScriptConfigFilePath = "./script-config.template.json",
    [Parameter(Mandatory=$false)][string]$ProtectedConfigFilePath = "./protected-config.template.json",
    [Parameter(Mandatory=$false)][string]$TempPath = "./tmp",
    [Parameter(Mandatory=$true)][securestring]$AdminPassword,
    [Parameter(Mandatory=$false)][string]$Location ="eastus",
    [Parameter(Mandatory=$false)][string]$VMSize="Standard_NC6",
    [Parameter(Mandatory=$false)][string]$BlobContainerName="default",
    [Parameter(Mandatory=$false)][string]$DiskEncryptionMode = "DATA",
    [Parameter(Mandatory=$false)][switch]$EncryptDisk,
    [Parameter(Mandatory=$false)][switch]$SkipArm,
    [Parameter(Mandatory=$false)][switch]$SkipCert,
    [Parameter(Mandatory=$false)][switch]$SkipAuth,
    [Parameter(Mandatory=$false)][switch]$Uninstall
)

enum LogLevel 
{
    Information = 2
    Warning = 3
    Error = 4
}

[LogLevel]$script:logLevel = [LogLevel]::Information

$script:user = $null
$script:adminName = $null
$script:isAuthenticated = $SkipAuth
$script:tenantId = $null
$script:appObjectId = $null
$script:clientId = $null
$script:clientSecret = $null
$script:clientIpAddress = $null
$script:nsgName = $null
$script:storageAccountName = $null
$script:containerName =$null
$script:sasToken = $null
$script:vmName = $null;
$script:vmFQDN = $null
$script:applicationName = $null;
$script:resourceLogsDiagArmLocation = "./arm/logs-resource-diagnostics.json"

function Write-Log {

    Param (
        [string]$Message,
        [LogLevel]$Level
    )

    if ($script:logLevel.value__ -le $Level.value__) {
        Write-Host "$([DateTime]::UtcNow.ToString("yyyy-MM-dd hh:mm:ss")) [$($Level.ToString().ToUpper())]: $Message"
    }
    
}

function Log-Info {
    
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute("PSUseApprovedVerbs", "")]
    Param (
        [string]$Message
    )

    Write-Log -Message $Message -Level Information
}

function Log-Warning {

    [Diagnostics.CodeAnalysis.SuppressMessageAttribute("PSUseApprovedVerbs", "")]
    Param (
        [string]$Message
    )

    Write-Log -Message $Message -Level Warning
}

function Log-Error {

    [Diagnostics.CodeAnalysis.SuppressMessageAttribute("PSUseApprovedVerbs", "")]
    Param (
        [string]$Message
    )

    Write-Log -Message $Message -Level Error
}

function Handle-Error {

    [Diagnostics.CodeAnalysis.SuppressMessageAttribute("PSUseApprovedVerbs", "")]
    Param (
        [string]$Message,
        [switch]$IsFatal
    )

    Log-Error "Error: $Message"

    if ($IsFatal) {
        Log-Error "Specify the random value as -Random '$Random' when running this script again to continue with the same resource naming scheme."
        Cleanup
        exit
    }
}

function Process-TemplateFile {

    [Diagnostics.CodeAnalysis.SuppressMessageAttribute("PSUseApprovedVerbs", "")]
    Param (
        [string]$Path,
        [string]$TempPath,
        [hashtable]$Parameters
    )

    if ((Test-Path -Path $Path) -eq $false) {
        Handle-Error -Message "Could not find '$Path'!" -IsFatal
    }

    if ((Test-Path -Path $TempPath) -eq $false) {
        New-Item -Path $TempPath -ItemType Directory
    }

    Log-Info "Reading '$Path'..."

    $content = Get-Content -Path $Path

    foreach ($key in $Parameters.Keys) {
        $content = $content.Replace("{$key}", $Parameters[$key])
    }

    $tempFilePath = Get-FileTempPath -OriginalPath $Path -TempPath $TempPath

    Log-Info "Writing '$tempFilePath'..."
    $content | Out-File -FilePath $tempFilePath

}

function Get-CurrentIp {

    $uri = "https://api.ipify.org/"

    Log-Info "Getting current client IP address (public IP) via '$uri'..."
    $script:clientIpAddress = Invoke-RestMethod -Method GET -Uri $uri -ErrorVariable IsError

    if ($null -ne $IsError.Exception -or [string]::IsNullOrWhiteSpace($script:clientIpAddress)) {
        Handle-Error -Message $IsError.Exception.Message -IsFatal
    }

    Log-Info "Current client IP address (public IP) reported as '$($script:clientIpAddress)'."

}

function Process-ArmTemplates {

    [Diagnostics.CodeAnalysis.SuppressMessageAttribute("PSUseApprovedVerbs", "")]
    Param()

    Get-CurrentIp

    $azContext = (az account show) | ConvertFrom-Json
    
    $script:tenantId = $azContext.tenantId

    if (-not [string]::IsNullOrWhiteSpace($AdminObjectId)) {
        $script:user = az ad user show --id $AdminObjectId --output json | ConvertFrom-Json      
    }
    else {
        Log-Info "Looking up info for current user '$($azContext.user.name)'..."
        $userList = az ad user list --filter "userPrincipalName eq '$($azContext.user.name)' or otherMails/any(m:m eq '$($azContext.user.name)') or mail eq '$($azContext.user.name)'" | ConvertFrom-Json 
        $script:user = $userList[0]
    }
    
    if ($null -eq $script:user) {
        Handle-Error -Message "No user found" -IsFatal
    }

    if ($null -ne $script:user.UserPrincipalName) {
        if ($script:user.UserPrincipalName.IndexOf("#EXT#") -ge 0) {
            $script:user.UserPrincipalName = $script:user.UserPrincipalName.Substring(0, $script:user.UserPrincipalName.IndexOf('#EXT')).Replace("_", "@")
        }
    }

    Log-Info "Tenant Id:       $($script:tenantId)"
    Log-Info "Current User:    $($script:user.UserPrincipalName)"
    
    $azContext = (az account show) | ConvertFrom-Json
    $script:tenantId = $azContext.tenantId
    $parameters = @{
        "prefix"            = $Prefix;
        "rand"              = $Random.ToLowerInvariant();
        "adminPassword"     = ConvertFrom-SecureString -SecureString $AdminPassword -AsPlainText;
        "currentClientIp"   = $script:clientIpAddress;
        "currentUserId"     = $script:user.objectId;
        "location"          = $Location;
        "vmSize"            = $VMSize;
        "containerName"     = $BlobContainerName;
        "tenantId"          = $script:tenantId;
    }

    Log-Info "Processing ARM templates..."
    Log-Info "Prefix:         $($parameters["prefix"])"
    Log-Info "Random:         $($parameters["rand"])"

    Process-TemplateFile -Path $ArmTemplateFilePath -TempPath $TempPath -Parameters $parameters
    Process-TemplateFile -Path $ArmTemplateParametersFilePath -TempPath $TempPath -Parameters $parameters

}


function Get-FileTempPath {

    Param (
        [string]$OriginalPath,
        [string]$TempPath
    )

    $fileName = [System.IO.Path]::GetFileName($OriginalPath).Replace(".template", "")
    $tempFilePath = [System.IO.Path]::Combine($TempPath, $fileName)

    return $tempFilePath

}

function Connect-Azure {

    if ($script:isAuthenticated -eq $false) {

        az account clear

        Log-Info "Tenant ID '$($Tenant)'..."

        az login --tenant $Tenant

        if (-not $?) {
            Handle-Error "Could not login!" -IsFatal
        }

        az account set --subscription $Subscription

        $script:isAuthenticated = $true
    }
    else {
        az account set --subscription $Subscription
    }
}

function PreProcess-Azure {

    [Diagnostics.CodeAnalysis.SuppressMessageAttribute("PSUseApprovedVerbs", "")]
    Param()

    $armTemplateParametersTempPath = Get-FileTempPath -OriginalPath $ArmTemplateParametersFilePath -TempPath $TempPath

    Log-Info ""
    Log-Info "Acquiring values from '$armTemplateParametersTempPath'..."

    $armTemplateParametersContents = (Get-Content -Path $armTemplateParametersTempPath | ConvertFrom-Json)

    $script:adminName = $armTemplateParametersContents.parameters.virtualMachine_admin.value

    $script:nsgName = $armTemplateParametersContents.parameters.networkSecurityGroup_name.value

    $script:storageAccountName = $armTemplateParametersContents.parameters.storageAccount_name.value
    $script:containerName = $armTemplateParametersContents.parameters.container_name.value

    $Location = $armTemplateParametersContents.parameters.location.value
    $script:vmName = $armTemplateParametersContents.parameters.virtualMachine_name.value
    $script:vmFQDN = "$($vmName).$($location).cloudapp.azure.com"

    $script:keyvaultName = $armTemplateParametersContents.parameters.keyvvault_name.value
    $script:LogWorkspaceName = $armTemplateParametersContents.parameters.loganalytics_name.value
    $script:VNET=$armTemplateParametersContents.parameters.virtualNetwork_name.value
    $script:PIP=$armTemplateParametersContents.parameters.publicIPAddresses_name.value
    $script:vmNIC=$armTemplateParametersContents.parameters.networkInterface_name.value

    Log-Info ""
    Log-Info "Admin Name:      $($script:adminName)"
    Log-Info "NSG Name:        $($script:nsgName)"
    Log-Info "Storage Account: $($script:storageAccountName)"
    Log-Info "Location:        $($Location)"
    Log-Info "Container:       $($script:containerName)"
    Log-Info "VM Name:         $($script:vmName)"
    Log-Info "VM FQDN:         $($script:vmFQDN)"

}

function Import-Dependencies {

    Log-Info "Checking for Azure CLI..."

    az --version

    if (-not $?) {
        Handle-Error "You must install the Azure CLI." -IsFatal
    }

}

function Deploy-Azure {  

    if ($SkipArm -eq $false) {
        Log-Info "Looking for resource group '$ResourceGroup'..."
        if ((az group exists --name $ResourceGroup) -eq $false) {
            Log-Info "Resource group not found. Creating..."
            az group create --name $ResourceGroup --location $Location --verbose
        }

        $armTemplateTempPath = Get-FileTempPath -OriginalPath $ArmTemplateFilePath -TempPath $TempPath
        $armTemplateParametersTempPath = Get-FileTempPath -OriginalPath $ArmTemplateParametersFilePath -TempPath $TempPath

        Log-Info "Validating ARM template..."
        if (-Not(az deployment group validate --parameters $armTemplateParametersTempPath --resource-group $ResourceGroup --template-file $armTemplateTempPath --verbose)) {
            throw "Invalid template!!"
            Break
        }

        Log-Info "Deploying ARM template..."
        az deployment group create -g $ResourceGroup --template-file $armTemplateTempPath --parameters $armTemplateParametersTempPath --verbose
        Log-Info "Deploying ARM template: Done."
    }
    else {
        Log-Warning "Skipping ARM deployment."
    }
}

function Get-CryptoRandom {

    Param (
        [int]$Min,
        [int]$Max,
        [System.Collections.ArrayList]$Exclude,
        [int]$Count = 1
    )

    $rng = [System.Security.Cryptography.RNGCryptoServiceProvider]::Create()
            
    if ($Max -eq $Min)
    {
        Handle-Error "You must specify a range of numbers." -IsFatal
    }

    $randArray = New-Object System.Collections.ArrayList

    $range = $Max - $Min + 1
    
    for ($i = 0; $i -lt $Count; $i++) {
        do {
            $bytes = New-Object byte[](4)
            
            $rng.GetBytes($bytes)    
            
            $random = [System.BitConverter]::ToUInt32($bytes, 0)
            $value = $Min + ($random % $range)
        } while ($null -eq $Exclude -or $Exclude -contains $value)
        
        $randArray.Add($value) > $null
    }

    return $randArray
}

function Get-SASToken {
    $keys = (az storage account keys list -g $ResourceGroup -n $script:storageAccountName) | ConvertFrom-Json
    $script:sasToken = $keys[0].Value
}

function Format-JHubUserName {
    Param (
        [string]$Name
    )

    return ($Name -replace "(\s|\(|\)|,|\.)").ToLowerInvariant()
}

function Execute-PostDeployScript {

    [Diagnostics.CodeAnalysis.SuppressMessageAttribute("PSUseApprovedVerbs", "")]
    Param()

    Log-Info "Executing post-deployment script on remote VM '$($script:vmName)'..."

    $extensionPublisher = "Microsoft.Azure.Extensions"
    $extensionType = "CustomScript"
    
    Log-Info "Looking for existing post-deployment script execution..."
    if (az vm extension show -g $ResourceGroup --vm-name $script:vmName -n $extensionType --only-show-errors) {
        Log-Info "Post-deployment script already executed."
    }
    else {
        Log-Info "Setting extension in VM..."
        az vm extension set --name $extensionType --publisher $extensionPublisher --version "2.0" --vm-name $script:vmName --resource-group $ResourceGroup --protected-settings $ProtectedConfigFilePath --verbose
        Log-Info "Extension set in VM."
    }
}

function EncryptAllDisk {
    
    if ($EncryptDisk -eq $true) {
        Log-Info "Encrypting disks..."
        az vm encryption enable --disk-encryption-keyvault $script:keyvaultName --name $script:vmName --resource-group $ResourceGroup --volume-type $DiskEncryptionMode --verbose
        az vm encryption show --name $script:vmName --resource-group $ResourceGroup
    }
    else {
        Log-Warning "Skipping Disk encryption"
    }
}

function EnableActivityLogsDiag {

    Log-Info "Enabling Resources Logs Diagnostics..."
    az provider register --namespace 'microsoft.insights' --verbose 
    az deployment group create -g $ResourceGroup --template-file $script:resourceLogsDiagArmLocation --parameters settingNameSuffix=$Prefix workspaceId="$script:LogWorkspaceName" storageAccountId="$script:storageAccountName" storageName="$script:storageAccountName" keyVaultName="$script:keyvaultName" vnetName="$script:VNET" vmPIP="$script:PIP"  nsgName="$script:nsgName"  vmNICName="$script:vmNIC" --verbose
}

function Restart-VM {

    Log-Info "Attempting to restart VM '$($script:vmName)'..."
    az vm restart -g $ResourceGroup -n $script:vmName --verbose
    Log-Info "VM restarted successfully. Please wait a few moments before attempting to connect to the resource."

}
function Display-Summary {

    [Diagnostics.CodeAnalysis.SuppressMessageAttribute("PSUseApprovedVerbs", "")]
    Param()

    Write-Host ""
    Write-Host "You can connect via Azure Bastion with the user $($script:adminName) and the specify password at deployment"
    Write-Host ""
    Write-Host ""

}

function Post-Deployment {

    [Diagnostics.CodeAnalysis.SuppressMessageAttribute("PSUseApprovedVerbs", "")]
    Param()

    Get-SASToken
    Execute-PostDeployScript
    Restart-VM
    
}

function Cleanup {

    if (Test-Path -Path $TempPath) {
        Remove-Item -Path $TempPath -Recurse -ErrorVariable IsError

        if ($null -ne $IsError.Exception) {
            Log-Error "Error: $($IsError.Exception.Message)"
            Log-Error "Could not cleanup $TempPath! You should delete this manually."
        }
    }

}

function Remove-ResourceGroup {

    $confirm = Read-Host -Prompt "This will completely remove the resource group '$ResourceGroup'. Type yes to confirm"

    if ([string]::Compare($confirm, "yes", $true) -ne 0) {
        Log-Warning "Aborting uninstall."
        exit
    }

    Log-Info "Removing resource group '$ResourceGroup'..."
    az group delete -n $ResourceGroup --verbose
    Log-Info "Resource group '$ResourceGroup' removed."

}

function Remove-ApplicationRegistration {

    Log-Info "Removing application registration '$($script:applicationName)'..."

    $appRegList = az ad app list --display-name $script:applicationName | ConvertFrom-Json

    if ($null -ne $appRegList -and $appRegList[0].Length -ne 0 ) {
        az ad app delete --id $appRegList[0].objectId
        Log-Info "Application registration '$($script:applicationName)' removed."
    }
    else
    {
        Log-Info "Application registration '$($script:applicationName)' doesn't exist."
    }
   
}
   
function Run-Deployment {

    [Diagnostics.CodeAnalysis.SuppressMessageAttribute("PSUseApprovedVerbs", "")]
    Param()

    Log-Info "Deploying resources..."

    Import-Dependencies
    Connect-Azure
    Process-ArmTemplates
    PreProcess-Azure
    Deploy-Azure
    Post-Deployment
    EnableActivityLogsDiag
    EncryptAllDisk
    Cleanup

    Log-Info "Deployment completed."

    Display-Summary  

}

function Run-Uninstall {

    [Diagnostics.CodeAnalysis.SuppressMessageAttribute("PSUseApprovedVerbs", "")]
    Param()

    Log-Info "Uninstalling resources..."

    Connect-Azure
    Remove-ResourceGroup
    Remove-ApplicationRegistration

}

if ($Random -eq $null -or $Random -eq "") {
    if ($Uninstall) {
        Handle-Error -Message "You must specify the random unique identifier used for your environment!" -IsFatal
    }
    $Random = -join ((65..90) + (97..122) | Get-Random -Count 5 | ForEach-Object {[char]$_})
} 
elseif ($Random.Length -lt 3) {

    Handle-Error -Message "You must specify a random value of at least 3 characters." -IsFatal
}

if ($ResourceGroup -eq $null -or $ResourceGroup -eq "") {
    $ResourceGroup = "$Prefix-$Random-jhub"
}

$script:applicationName = "$Prefix-$Random-jhub-app"

if ($Uninstall) {
    Run-Uninstall
}
else {
    Run-Deployment
}