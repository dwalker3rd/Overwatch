## Copyright (c) Microsoft Corporation. All rights reserved.
## Licensed under the MIT License.
Param (
    [Parameter(Mandatory = $True)]
    [string] $Subscription,
    [Parameter(Mandatory = $True)]
    [string] $Tenant,
    [Parameter(Mandatory = $True)]
    [string] $ManagementGroupId,
    [Parameter(Mandatory = $True)]
    [string] $OMSSubscription,
    [Parameter(Mandatory = $True)]
    [string] $OMSResourceGroup,
    [Parameter(Mandatory = $True)]
    [string] $OMSWorkspaceName,
    [Parameter(Mandatory = $False)]
    [string] $OMSLocation = "eastus",
    [Parameter(Mandatory = $False)]
    [string] $NetworkWatcherLocation = "eastus",
    [Parameter(Mandatory = $False)]
    [string] $NetworkWatcherRG = "NetworkWatcherRG",
    [Parameter(Mandatory = $False)]
    [string] $SubscriptionAdminObjectId,
    [Parameter(Mandatory = $False)]
    [string] $ASCContactEmail,
    [Parameter(Mandatory = $False)]
    [string] $ASCContactPhone,
    [Parameter(Mandatory = $False)]
    [switch] $AssignSecurityContact,
    [Parameter(Mandatory = $False)]
    [switch] $AddASCPolicyToMngtGroup,
    [Parameter(Mandatory = $False)]
    [switch] $AddAdminToSubscription,
    [Parameter(Mandatory = $False)]
    [switch] $DeployGlobalOMS,
    [Parameter(Mandatory = $False)]
    [switch] $SkipHIPAAPolicy,
    [Parameter(Mandatory = $False)]
    [switch] $SkipAuth
)

$script:isAuthenticated = $SkipAuth
$script:billingScope = $null
$script:subscriptionId = $Subscription
$script:hipaaPolicyArmLocation = "./arm/hipaa-policy.json"
$script:globalOMSArmLocation = "./arm/global-oms-workspace.json"
$script:QualysPolicyArmLocation = "./arm/default-vulnerability-assessment.json"

enum LogLevel {
    Information = 2
    Warning = 3
    Error = 4
}

[LogLevel]$script:logLevel = [LogLevel]::Information
function Write-Log {
    Param (
        [string] $Message,
        [LogLevel] $Level
    )

    if ($script:logLevel.value__ -le $Level.value__) {
        Write-Host "$([DateTime]::UtcNow.ToString("yyyy-MM-dd hh:mm:ss")) [$($Level.ToString().ToUpper())]: $Message"
    }
}
function Log-Info {
    Param (
        [string] $Message
    )

    Write-Log -Message $Message -Level Information
}

function Log-Warning {
    Param (
        [string] $Message
    )

    Write-Log -Message $Message -Level Warning
}

function Log-Error {
    Param (
        [string] $Message
    )

    Write-Log -Message $Message -Level Error
}

function Handle-Error {
    Param (
        [string] $Message,
        [switch] $IsFatal
    )

    Log-Error "Error: $Message"

    if ($IsFatal) {
        exit
    }
}

function Invoke-MsGraphApi {
    Param (
        [string] $Method,
        [string] $Uri,
        [string] $ContentType,
        [string] $Body,
        [string] $ResourceType = "arm"
    )

    $response = az account get-access-token --resource-type $ResourceType
    $accessToken = ($response | ConvertFrom-Json).accessToken

    $headers = @{
        "Authorization" = "Bearer $accessToken";
    }

    $result = $null

    $sleepTimeInSeconds = 10
    $retryCount = 0
    $maxRetries = 3
    $isCompleted = $False
    Log-Info "Calling api..."
    do {
        try {
            if ($null -ne $Body) {
                $result = Invoke-RestMethod -Method $Method -Uri $Uri -Headers $headers -Body $Body -ContentType $ContentType -ErrorVariable IsError
            }
            else {
                $result = Invoke-RestMethod -Method $Method -Uri $Uri -Headers $headers -ContentType $ContentType -ErrorVariable IsError
            }

            if ($null -ne $IsError.Exception) {
                $retryCount += 1
                Handle-Error $IsError.Exception.Message

                Log-Info "Waiting for $sleepTimeInSeconds seconds before retrying..."
                Start-Sleep -Seconds $sleepTimeInSeconds
            }
            else {
                $isCompleted = $True
            }
        }
        catch {
            $retryCount += 1
            Handle-Error $_.ToString()

            Log-Info "Waiting for $sleepTimeInSeconds seconds before retrying..."
            Start-Sleep -Seconds $sleepTimeInSeconds
        }
    } while (-not $isCompleted -and $retryCount -lt $maxRetries)

    if (-not $isCompleted) {
        Handle-Error "Could not set required permissions." -IsFatal
    }

    return $result
}

function Connect-Azure {

    if ($script:isAuthenticated -eq $False) {

        az account clear

        Log-Info "Tenant ID '$($Tenant)'..."

        az login --tenant $Tenant

        if (-not $?) {
            Handle-Error "Could not login!" -IsFatal
        }

        az account set --subscription $Subscription

        $script:isAuthenticated = $True
    }
    else {
        az account set --subscription $Subscription
    }
}

function OnboardSecurityCenter {

    #Register Prroviders
    az provider register --namespace 'Microsoft.Security' --verbose
    az provider register --namespace 'Microsoft.PolicyInsights' --verbose
    az provider register --namespace 'Microsoft.Management' --verbose    
    az provider register --namespace 'microsoft.insights' --verbose  

    if ($AssignSecurityContact -eq $True) {
        #Create security Contact
        Log-Info "Creating security contact"
        az security contact create -n "main" --email $ASCContactEmail --phone $ASCContactPhone --alert-notifications 'on' --alerts-admins 'on'
        
    }else {
        Log-Info "Skipping creation of security contact"
    }

    Log-Info "Upgrading Defender Plan and Enabling ASC Default Policies (e.g. Data Protection Suite, Security Benchmark)"
    Log-Info "Waiting 60 seconds for providers..."
    Start-Sleep -Seconds 60
    #Upgrade Defender Plan
    az security pricing create -n VirtualMachines --tier 'standard' --subscription $script:subscriptionId --verbose
    az security pricing create -n StorageAccounts --tier 'standard' --subscription $script:subscriptionId --verbose
    az security pricing create -n KeyVaults --tier 'standard' --subscription $script:subscriptionId --verbose
    az security pricing create -n KubernetesService --tier 'standard' --subscription $script:subscriptionId --verbose
    az security pricing create -n SqlServers --tier 'standard' --subscription $script:subscriptionId --verbose
    az security pricing create -n AppServices --tier 'standard' --subscription $script:subscriptionId --verbose

    Log-Info "Enabling OMS workspace for security center..."
    #enable OMS workspace for security center
    az security workspace-setting create -n default --target-workspace "/subscriptions/$OMSSubscription/resourceGroups/$OMSResourceGroup/providers/Microsoft.OperationalInsights/workspaces/$OMSWorkspaceName" --verbose

    Log-Info "Enabling auto-provision of Log Analytics agent on your Azure VM..."
    #Enable auto-provision of Log Analytics agent on your Azure VM
    az security auto-provisioning-setting update --auto-provision "On" --name "default" --subscription $Subscription --verbose

    if($SkipHIPAAPolicy -eq $True)
    {
        Log-Info "Skipping HIPAA Policy initiative..."
    }
    else {
        Log-Info "Enabling HIPAA Policy initiative..."
        #Set hipaa Policy initiative
        $hipaaPolicyId = az policy set-definition list --query "[?displayName=='HITRUST/HIPAA'].name" | ConvertFrom-Json
    
        az deployment sub create --location $OMSLocation --subscription $script:subscriptionId --name "HIPAADeployment-$script:subscriptionId" --template-file $script:hipaaPolicyArmLocation --parameters policyAssignmentName="HIPAA" policyDefinitionID=$hipaaPolicyId displayName="HITRUST/HIPAA ($script:subscriptionId)" scope="/subscriptions/$script:subscriptionId" location=$OMSLocation --verbose
    }

    Log-Info "Adding Enable Azure Security Center on your subscription policy on subscription: ($script:subscriptionId)"

    $ascSubPolicyId = az policy definition list --query "[?displayName=='Enable Azure Security Center on your subscription'].name" | ConvertFrom-Json 
    az policy assignment create  --name "Enable ASC on Subscription" --policy $ascSubPolicyId --display-name "Enable ASC on Subscription ($script:subscriptionId)"  --assign-identity --identity-scope "/subscriptions/$script:subscriptionId" --scope "/subscriptions/$script:subscriptionId" --role Contributor --location $OMSLocation --verbose   
    
    if ($AddASCPolicyToMngtGroup -eq $True) {
        
        Log-Info "Adding Enable Azure Security Center on your subscription policy on management group: ($ManagementGroupId) "
        #Add policy to check all subscritpion under a management group are register to security center
        $ascMgntGroupPolicyId = az policy definition list --query "[?displayName=='Enable Azure Security Center on your subscription'].name" | ConvertFrom-Json

        az policy assignment create  --name "Enable ASC on Group" --policy $ascMgntGroupPolicyId --display-name "Enable ASC on Management Group ($ManagementGroupId)"  --assign-identity --identity-scope "/providers/Microsoft.Management/managementGroups/$ManagementGroupId" --scope "/providers/Microsoft.Management/managementGroups/$ManagementGroupId" --role Contributor --location $OMSLocation --verbose   
        
    }else {
        Log-Info "Skipping adding Enable Azure Security Center on your subscription policy on management group: ($ManagementGroupId) "
    }

    Log-Info "Enabling Custom Policy to enable Default Vulnerability Assetsment with Qualys..."

    $qualysPolicyName="Deploy Qualys VA Policy"
    $ascMgntGroupPolicyId = az policy definition list --query "[?displayName=='$qualysPolicyName'].name" | ConvertFrom-Json
    az deployment sub create --location $OMSLocation --subscription $script:subscriptionId --name "EnableQualys-$script:subscriptionId" --template-file $script:QualysPolicyArmLocation --parameters policyName=$qualysPolicyName  --verbose
   
    $qualysPolicyNameId = az policy definition list --query "[?displayName=='$qualysPolicyName'].name" | ConvertFrom-Json

    az policy assignment create  --name "DeployQualysVA" --policy $qualysPolicyNameId --display-name "Deploy Qualys VS On ($script:subscriptionId)"  --assign-identity --identity-scope "/subscriptions/$script:subscriptionId" --scope ""/subscriptions/$script:subscriptionId"" --role Contributor --location $OMSLocation --verbose   

}

function SetupNetworkWatchers {

    Log-Info "Looking for NetworkWatcherRG resource group '$NetworkWatcherRG'..."
    if ((az group exists --name $NetworkWatcherRG --subscription $Subscription) -eq $false) {
        Log-Info "Resource group not found. Creating..."
        az group create --name $NetworkWatcherRG --location $NetworkWatcherLocation --subscription $Subscription  --verbose
    }
    Log-Info "Enabling Network watchers"
    az network watcher configure -g $NetworkWatcherRG  -l $NetworkWatcherLocation --enabled true --verbose

}
function AddAdminToSubscription {

    if($AddAdminToSubscription -eq $True)
    {

        Log-Info "adding Account admins to subscription owner role"
        az role assignment create --assignee $SubscriptionAdminObjectId --role "Owner" --scope "/subscriptions/$script:subscriptionId" --verbose

    } else {
        Log-Info "Skipping adding Account admins to subscription owner role"
    }
}

function AddSubscriptionToManagementGroup {

    Log-Info "adding subscription to management group ($ManagementGroupId)"
    az account management-group subscription add --name $ManagementGroupId --subscription $script:subscriptionId --verbose
    
}

function CreateOMSWorkspace {

    if($DeployGlobalOMS -eq $True) 
    {
        Log-Info "Creating OMS workspace creation.."
        az deployment group create --resource-group $OMSResourceGroup --subscription $OMSSubscription --name "OMSDeployment-$OMSSubscription" --template-file $script:globalOMSArmLocation --parameters workspaceName=$OMSWorkspaceName --verbose

    }else {
        Log-Info "Skipping OMS workspace creation.."
    }
}

#Script execution starts here
Connect-Azure


az config set extension.use_dynamic_install=yes_without_prompt

Log-Info "Looking for OMS resource group '$OMSResourceGroup'..."
if ((az group exists --name $OMSResourceGroup --subscription $OMSSubscription) -eq $false) {
    Log-Info "Resource group not found. Creating..."
    az group create --name $OMSResourceGroup --location $OMSLocation --subscription $OMSSubscription  --verbose
}

AddAdminToSubscription

AddSubscriptionToManagementGroup

CreateOMSWorkspace

OnboardSecurityCenter

SetupNetworkWatchers
