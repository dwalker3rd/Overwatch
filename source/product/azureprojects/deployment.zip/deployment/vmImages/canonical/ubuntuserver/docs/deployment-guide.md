# Data Science Multi-User Environment
Refer to the following sections for installation and maintenance operations:
* [Deployment](#Deployment)
* [Post-Deployment](#Post-Deployment)
* [Maintenance](#Maintenance)
* [Uninstallation](#Uninstallation)

## Deployment
Refer to the following sections for more information regarding deployment:
* [Performing a Deployment](#Performing-a-Deployment)
* [Advanced Deployment Configuration](#Advanced-Deployment-Configuration)
* [Modifying the Location of Deployment Files](#Modifying-the-Location-of-Deployment-Files)

### Performing a Deployment
The following describes how to deploy this VM configuration.

*Please note the deployment will initially attempt to restrict access to **only** the public IP address of the deploying user. This process is not 100% accurate as, based on how Internet traffic is routed within your networking infrastructure, you may need to add additional IP address ranges for the deploying user to have access.*

*Additionally, if you want to grant access from additional locations you will need to add the appropriate public IP address range(s) to the network security group (NSG) rules. Additionally, based on how Internet traffic is routed within your networking infrastructure you may need to add additional IP address ranges for the deploying user to have access.*

#### Deploying from [Azure Portal Cloud Shell Console](https://docs.microsoft.com/en-us/azure/cloud-shell/quickstart-powershell) (Recommended)

1.  Download execution scripts to cloud shell storage using the cloud shell PowerShell console.

```ps
Invoke-WebRequest -Uri "https://dsarchitectures3f4g5.blob.core.windows.net/dstemplates/base-template-linux-v2.0.zip" -OutFile "base-template.zip"
```

2. Extract execution scripts zip file:

```ps
Expand-Archive -LiteralPath ./base-template.zip -DestinationPath ./base-template
```

3. Change to execution directory:

```ps
cd ./base-template/config
```

4. Run the following command with the parameter placeholders replaced with the appropriate values for your environment:

```ps
.\deploy.ps1 -Subscription "subscriptionId" -Tenant "TenantId" -Prefix "uniquePrefix" -Random "randomValue" -ResourceGroup "resourceGroupName" -VMSize "VMSize" -location "location"
```
***Note:** When using the Azure Cloud Shell you need to add your current IP Address to the network security group (NSG) of the VM to access the resources.*

#### Deploying from a windows machine

1.  Download execution scripts.

```ps
Invoke-WebRequest -Uri "https://dsarchitectures3f4g5.blob.core.windows.net/dstemplates/base-template-linux-v2.0.zip" -OutFile "base-template.zip"
```

2. Extract execution scripts zip file:

```ps
Expand-Archive -LiteralPath ./base-template.zip -DestinationPath ./base-template
```

3. Change to execution directory:

```ps
cd ./base-template/config
```

4. Run the following command to allow unrestricted execution to the powershell script

```ps
 Set-ExecutionPolicy -ExecutionPolicy Unrestricted -Scope Process
```

5. Run the following command with the parameter placeholders replaced with the appropriate values for your environment:

```ps
.\deploy.ps1 -Subscription "subscriptionId" -Tenant "TenantId" -Prefix "uniquePrefix" -Random "randomValue" -ResourceGroup "resourceGroupName" -VMSize "VMSize" -location "location"
```

***Note:** If you have additional configuration needs please refer to the [Advanced Configuration](#Advanced-Deployment-Configuration) section.*

### Parameters (deploy.ps1)

|Required|Name|Description|Default|
|-|-|-|-|
|✓|Subscription|The target Azure Subscription id.|*none*|
|✓|Tenant|Azure Active Directory Tenant Id|*none*|
|✓|Prefix|A unique prefix for resources.|*none*|
||Random|A random value to help ensure uniqueness of resource names.|A pseudo-random selection of 5 characters.|
||adminObjectId|Active Directory Object Id of user to be added as the default admin of the VM|*none*|
||ResourceGroup|The target Azure Resource Group name.|{Prefix}-{Random}-jhub|
||VMSize|Azure VM Sku|Standard_NC6|
||location|Location of the resources|eastus|
||SkipArm|A switch specifying to skip the ARM deployment.|N/A|
||SkipCert|A switch specifying to skip requesting an SSL certificate from Let's Encrypt.|N/A|
||SkipAuth|Skip authorization. |N/A|
||Uninstall|A switch specifying to uninstall a deployment. **You must specify the -Random parameter with the correct value for your environment for this mode**.|N/A|

<table>
    <tr>
        <td style='background-color: dodgerblue; color: white;'>
            Example
        </td>
        <td>
            <code>
            .\deploy.ps1 -Subscription "00000000-0000-0000-0000-000000000000" -Tenant "00000000-0000-0000-0000-000000000000" -Prefix cdr -Random dev01 -ResourceGroup "test-deploy-ru" -VMSize "Standard_NC6" -location westus2
            </code>
        </td>
    </tr>
</table>

4. That's it! Now you should be able to connect to your VM via SSH and to JupyterHub in the browser.

### Advanced Deployment Configuration
For advanced configuration scenarios such as but not limited to specifying an existing storage account in the target resource group, edit the [azuredeploy.parameters.template.json](../config/arm/azuredeploy.parameters.template.json) file before running the installation script.

The following details the effect each parameter has on the deployed solution:
|Name|Description|
|-|-|
|virtualMachine_admin|The admin account name for the virtual machine.|
|storageAccount_name|The name for the storage account resource. If you want to use an existing storage account in the target resource group make sure this parameter reflects the name of the existing resource.|
|container_name|The name of the common file container. **You should not change this.**|

### Modifying the Location of Deployment Files
If the source location of deployment files changes (e.g. into a public GitHub repository), the following items need to be updated in the code:

|File|Properties/Parameters|Description|
|-|-|-|
|[protected-config.template.json](../config/protected-config.template.json)|fileUris|The URL the CustomScript extension should use to pull the post-deployment script.|
|[deploy.ps1](../config/deploy.ps1)|SourceRepo|Update the default value for the SourceRepo parameter. Alternatively, just specify the correct value when executing from PowerShell.|



## Post-Deployment
You will need to manually install your SSL certificate and private key if you chose to not have an SSL certificate requested from LetsEncrypt during the deployment process. Perform the following steps:

1. Login to the VM via SSH as a user with admin permissions.
1. Copy the SSL certificate to `/etc/letsencrypt/live/{VM FQDN}/fullchain.pem` via SCP.
1. Copy the SSL private key to `/etc/letsencrypt/live/{VM FQDN}/privkey.pem` via SCP.
1. Restart the JupyterHub service with the command `sudo systemctl restart jupyterhub`.

## Maintenance
The following provides detailed for the following maintenance tasks:

1. [Add a new ssh user](#Add-a-new-ssh-user)
1. [Add a new JupyterHub admin](#Add-a-new-JupyterHub-admin)
1. [Add a new VM ssh admin](#Add-a-new-VM-admin)
1. [Revoke SSL certificate](#Revoke-SSL-certificate)
1. [Uninstall resources](#Uninstall-resources)

### Add a new ssh user

1. Add the user to the **Virtual Machine User Login** role for the VM resource in the Azure portal.

### Add a new JupyterHub admin
Perform the following steps to grant admin access to a JupyterHub user:

1. Connect to the VM via SSH as a user with admin permissions.
2. Edit the [/etc/jupyter/jupyterhub_config.py](../multi-user-process-jhub/etc/jupyterhub/jupyterhub_config.py) file on the VM and add the user's normalized (refer to the function `normalize_username` for the normalization rules) display name to the `c.Authenticator.admin_users` property.<br /><br />Alternatively, you can add the user via the JupyterHub Admin control panel.

### Add a new VM admin

1. Add the user to the **Virtual Machine Admin Login** role for the VM resource in the Azure portal.

### Revoke SSL certificate
There may be multiple reasons you need to revoke the SSL certificate.

If you manually installed an SSL certificate after the deployment process you will need to refer to your own internal documentation for the process regarding the removal of an SSL certificate.

If you acquired an SSL certificate as part of the installation process, the easiest way to revoke and remove the SSL certificate is to perform the following steps:

1. Connect to the VM via SSH as a user with admin rights.
1. Ensure the `revoke-cert.sh` script is present in the `/usr/bin` folder.
1. Add execution permissions to the `revoke-cert.sh` script with the command `sudo chmod 700 /usr/bin/revoke-cert.sh`.
1. Execute the `revoke-cert.sh` script with the command `sudo /usr/bin/revoke-cert.sh`.
1. Answer `yes` to the prompt when asked if you want to delete the cert(s) you just revoked.
1. You should see output similar to the following:

```sh
Saving debug log to /var/log/letsencrypt/letsencrypt.log
Starting new HTTPS connection (1): acme-v02.api.letsencrypt.org

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
Would you like to delete the cert(s) you just revoked, along with all earlier
and later versions of the cert?
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
(Y)es (recommended)/(N)o: Y

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
Deleted all files relating to certificate
cdrejkncwusjhubvm01.westus2.cloudapp.azure.com.
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
Congratulations! You have successfully revoked the certificate that was located
at
/etc/letsencrypt/live/cdrejkncwusjhubvm01.westus2.cloudapp.azure.com/fullchain.pem

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
```

### Renew SSL Certificate

1. Connect to the VM via SSH as a user with admin rights.
1. Execute the following command:

```sh
sudo certbot renew && sudo systemctl restart jupyterhub
```


## Uninstallation
Perform the following steps to uninstall resources:

1. Make note of the *prefix* and *random value* used when installing your resources. This can be determined by any resource name.

#### Example:
```ps
cdrnbepywusjhubvm01
[ ][   ]
 ^   ^
 |   |
 |   +--- Random value
 |
 +------- Prefix
```

2. It is recommended you follow the steps to [revoke the SSL certificate](#Revoke-SSL-certificate) if you will no longer be using it. If you are migrating to a new resource, make sure and copy the SSL certificate and private key off of the VM before uninstalling.
3. Navigate to the cloned repository and run the following command:

```ps
.\deploy.ps1 -Subscription {subscriptionId} -Tenant {TenantId} -ResourceGroup {resourceGroupName} -Prefix {prefixValue} -Random {randomValue} -Uninstall
```

Refer to the previous [parameters](#Parameters-deployps1) for more information regarding the parameters.

The script will remove all of the resources in the resource group and the application registration.


## Troubleshooting

### Troubleshooting Jupyterhub service

1. To troubleshoot Jupyterhub service run the below command to check the logs:

```sh
sudo journalctl -r -u jupyterhub
```
