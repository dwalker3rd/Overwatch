## Copyright (c) Microsoft Corporation. All rights reserved.
## Licensed under the MIT License.
Param (
    [Parameter(Mandatory=$True)]
    [string] $Subscription,
    [Parameter(Mandatory=$True)]
    [string] $Tenant,
    [Parameter(Mandatory=$True)]
    [string] $ResourceGroup,
    [Parameter(Mandatory=$True)]
    [string] $Prefix,
    [Parameter(Mandatory=$True)]
    [string] $Random,
    [Parameter(Mandatory=$False)]
    [string] $adminObjectId,
    [Parameter(Mandatory=$False)]
    [string] $ArmTemplateFilePath = "./arm/azuredeploy.template.json",
    [Parameter(Mandatory=$False)]
    [string] $ArmTemplateParametersFilePath = "./arm/azuredeploy.parameters.template.json",
    [Parameter(Mandatory=$False)]
    [string] $ScriptConfigFilePath = "./script-config.template.json",
    [Parameter(Mandatory=$False)]
    [string] $ProtectedConfigFilePath = "./protected-config.template.json",
    [Parameter(Mandatory=$False)]
    [string] $TempPath = "./tmp",
    [Parameter(Mandatory=$False)]
    [string] $SshPrivateKeyPath = "~/.ssh/id_rsa",
    [Parameter(Mandatory=$False)]
    [string] $SshPublicKeyPath = "~/.ssh/id_rsa.pub",
    [Parameter(Mandatory=$False)]
    [string] $SourceRepo = "https://dsarchitectures3f4g5.blob.core.windows.net/dstemplates/config/multi-user-process-jhub-config-v2.zip",
    [Parameter(Mandatory=$False)]
    [string] $Location ="eastus",
    [Parameter(Mandatory=$False)]
    [string] $VMSize="Standard_NC6",
    [Parameter(Mandatory=$False)]
    [string] $BlobContainerName="default",
    [Parameter(Mandatory = $False)]
    [string] $DiskEncryptionMode = "DATA",
    [Parameter(Mandatory=$False)]
    [switch] $EncrypDisk,
    [Parameter(Mandatory=$False)]
    [switch] $SkipArm,
    [Parameter(Mandatory=$False)]
    [switch] $SkipCert,
    [Parameter(Mandatory=$False)]
    [switch] $SkipAADLoginExtension,
    [Parameter(Mandatory=$False)]
    [switch] $SkipAuth,
    [Parameter(Mandatory=$False)]
    [switch] $Uninstall
)

enum LogLevel 
{
    Information = 2
    Warning = 3
    Error = 4
}

[LogLevel]$script:logLevel = [LogLevel]::Information
$script:user = $null
$script:adminName = $null
$script:isAuthenticated = $SkipAuth
$script:tenantId = $null
$script:appObjectId = $null
$script:clientId = $null
$script:clientSecret = $null
$script:clientIpAddress = $null
$script:nsgName = $null
$script:storageAccountName = $null
$script:containerName =$null
$script:sasToken = $null
$script:vmName = $null;
$script:vmFQDN = $null
$script:sshPubKey = $null;
$script:applicationName = $null;
$script:resourceLogsDiagArmLocation = "./arm/logs-resource-diagnostics.json"
$script:vmLogsDiagArmLocation = "./arm/logs-vm-ubuntu-diagnostics.json"

function Write-Log {
    Param (
        [string] $Message,
        [LogLevel] $Level
    )

    if ($script:logLevel.value__ -le $Level.value__) {
        Write-Host "$([DateTime]::UtcNow.ToString("yyyy-MM-dd hh:mm:ss")) [$($Level.ToString().ToUpper())]: $Message"
    }
}

function Log-Info {
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute("PSUseApprovedVerbs", "")]
    Param (
        [string] $Message
    )

    Write-Log -Message $Message -Level Information
}

function Log-Warning {
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute("PSUseApprovedVerbs", "")]
    Param (
        [string] $Message
    )

    Write-Log -Message $Message -Level Warning
}

function Log-Error {
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute("PSUseApprovedVerbs", "")]
    Param (
        [string] $Message
    )

    Write-Log -Message $Message -Level Error
}

function Handle-Error {
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute("PSUseApprovedVerbs", "")]
    Param(
        [string] $Message,
        [switch] $IsFatal
    )

    Log-Error "Error: $Message"

    if ($IsFatal) {
        Log-Error "Specify the random value as -Random '$Random' when running this script again to continue with the same resource naming scheme."

        Cleanup

        exit
    }
}

function Process-TemplateFile {
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute("PSUseApprovedVerbs", "")]
    Param(
        [string] $Path,
        [string] $TempPath,
        [hashtable] $Parameters
    )

    if ((Test-Path -Path $Path) -eq $False) {
        Handle-Error -Message "Could not find '$Path'!" -IsFatal
    }

    if ((Test-Path -Path $TempPath) -eq $False) {
        New-Item -Path $TempPath -ItemType Directory
    }

    Log-Info "Reading '$Path'..."

    $content = Get-Content -Path $Path

    foreach ($key in $Parameters.Keys) {
        $content = $content.Replace("{$key}", $Parameters[$key])
    }

    $tempFilePath = Get-FileTempPath -OriginalPath $Path -TempPath $TempPath

    Log-Info "Writing '$tempFilePath'..."
    $content | Out-File -FilePath $tempFilePath

}

function CheckFor-SshKeyPair {

    [Diagnostics.CodeAnalysis.SuppressMessageAttribute("PSUseApprovedVerbs", "")]
    Param()

    if ([string]::IsNullOrWhiteSpace($SshPrivateKeyPath)) {
        $SshPrivateKeyPath = "~/.ssh/$($Prefix)_id_rsa"
    }

    if ($null -eq $PSVersionTable.Platform -or [string]::Compare($PSVersionTable.Platform, "Win32NT", $True) -eq 0) {
        $SshPrivateKeyPath = $SshPrivateKeyPath.Replace("~", $env:USERPROFILE).Replace("/", "\")

    }

    if ((Test-Path -Path $SshPrivateKeyPath) -eq $False) {

        Write-Host "Creating ssh key in: $SshPrivateKeyPath"

        ssh-keygen -t rsa -f $SshPrivateKeyPath

    }
    $SshPublicKeyPath = $SshPrivateKeyPath + ".pub"
        
    if ((Test-Path -Path $SshPublicKeyPath) -eq $False) {
        Handle-Error -Message "No SSH public key found!" -IsFatal

        $newSshPublicKeyPath = Read-Host -Prompt "Please specify the SSH public key location ($SshPublicKeyPath)"
        $SshPublicKeyPath = $newSshPublicKeyPath

    }
    
    $sshPubKeyContent = Get-Content -Path $SshPublicKeyPath

    $sshPubKeyParts = $sshPubKeyContent.Split(" ")
    $script:sshKeyPath= $SshPrivateKeyPath
    $script:sshPubKey = $sshPubKeyParts[0] + " " + $sshPubKeyParts[1]
    $script:sshPubKey = $script:sshPubKey.Trim()
}

function Get-CurrentIp {
    $uri = "https://api.ipify.org/"

    Log-Info "Getting current client IP address (public IP) via '$uri'..."
    $script:clientIpAddress = Invoke-RestMethod -Method GET -Uri $uri -ErrorVariable IsError

    if ($null -ne $IsError.Exception -or [string]::IsNullOrWhiteSpace($script:clientIpAddress)) {
        Handle-Error -Message $IsError.Exception.Message -IsFatal
    }

    Log-Info "Current client IP address (public IP) reported as '$($script:clientIpAddress)'."
}

function Process-ArmTemplates {

    [Diagnostics.CodeAnalysis.SuppressMessageAttribute("PSUseApprovedVerbs", "")]
    Param()

    CheckFor-SshKeyPair
    Get-CurrentIp

    $azContext = (az account show) | ConvertFrom-Json
    
    $script:tenantId = $azContext.tenantId

    if (-not [string]::IsNullOrWhiteSpace($adminObjectId)) {
        $script:user = az ad user show --id $adminObjectId --output json | ConvertFrom-Json      
    }
    else {
        Log-Info "Looking up info for current user '$($azContext.user.name)'..."
        $userList = az ad user list --filter "userPrincipalName eq '$($azContext.user.name)' or otherMails/any(m:m eq '$($azContext.user.name)') or mail eq '$($azContext.user.name)'" | ConvertFrom-Json 
        $script:user = $userList[0]
    }
    
    if ($null -eq $script:user) {
        Handle-Error -Message "No user found" -IsFatal
    }

    if ($null -ne $script:user.UserPrincipalName) {
        if ($script:user.UserPrincipalName.IndexOf("#EXT#") -ge 0) {
            $script:user.UserPrincipalName = $script:user.UserPrincipalName.Substring(0, $script:user.UserPrincipalName.IndexOf('#EXT')).Replace("_", "@")
        }
    }

    Log-Info "Tenant Id:       $($script:tenantId)"
    Log-Info "Current User:    $($script:user.UserPrincipalName)"

    $azContext = (az account show) | ConvertFrom-Json
    $script:tenantId = $azContext.tenantId
    $parameters = @{
        "prefix"            = $Prefix;
        "rand"              = $Random.ToLowerInvariant();
        "sshPubKey"         = $script:sshPubKey;
        "currentClientIp"   = $script:clientIpAddress;
        "currentUserId"     = $script:user.objectId;
        "location"          = $Location;
        "vmSize"            = $VMSize;
        "containerName"     = $BlobContainerName;;
        "tenantId"          = $script:tenantId;
    }

    Log-Info "Processing ARM templates..."
    Log-Info "Prefix:         $($parameters["prefix"])"
    Log-Info "Random:         $($parameters["rand"])"
    Log-Info "SSH Public Key: $($parameters["sshPubKey"])"

    Process-TemplateFile -Path $ArmTemplateFilePath -TempPath $TempPath -Parameters $parameters
    Process-TemplateFile -Path $ArmTemplateParametersFilePath -TempPath $TempPath -Parameters $parameters
}


function Get-FileTempPath {
    Param (
        [string] $OriginalPath,
        [string] $TempPath
    )

    $fileName = [System.IO.Path]::GetFileName($OriginalPath).Replace(".template", "")
    $tempFilePath = [System.IO.Path]::Combine($TempPath, $fileName)

    return $tempFilePath
}

function Connect-Azure {

    if ($script:isAuthenticated -eq $False) {

        az account clear

        Log-Info "Tenant ID '$($Tenant)'..."

        az login --tenant $Tenant

        if (-not $?) {
            Handle-Error "Could not login!" -IsFatal
        }

        az account set --subscription $Subscription

        $script:isAuthenticated = $True
    }
    else {
        az account set --subscription $Subscription
    }
}

function PreProcess-Azure {

    [Diagnostics.CodeAnalysis.SuppressMessageAttribute("PSUseApprovedVerbs", "")]
    Param()

    $armTemplateParametersTempPath = Get-FileTempPath -OriginalPath $ArmTemplateParametersFilePath -TempPath $TempPath

    Log-Info ""
    Log-Info "Acquiring values from '$armTemplateParametersTempPath'..."

    $armTemplateParametersContents = (Get-Content -Path $armTemplateParametersTempPath | ConvertFrom-Json)

    $script:adminName = $armTemplateParametersContents.parameters.virtualMachine_admin.value

    $script:nsgName = $armTemplateParametersContents.parameters.networkSecurityGroup_name.value

    $script:storageAccountName = $armTemplateParametersContents.parameters.storageAccount_name.value
    $script:containerName = $armTemplateParametersContents.parameters.container_name.value

    $Location = $armTemplateParametersContents.parameters.location.value
    $script:vmName = $armTemplateParametersContents.parameters.virtualMachine_name.value
    $script:vmFQDN = "$($vmName).$($location).cloudapp.azure.com"



    $script:keyvaultName = $armTemplateParametersContents.parameters.keyvvault_name.value
    $script:LogWorkspaceName = $armTemplateParametersContents.parameters.loganalytics_name.value
    $script:VNET=$armTemplateParametersContents.parameters.virtualNetwork_name.value
    $script:PIP=$armTemplateParametersContents.parameters.publicIPAddresses_name.value
    $script:vmNIC=$armTemplateParametersContents.parameters.networkInterface_name.value
    $script:dataFactory=$armTemplateParametersContents.parameters.adf_name.value

    Log-Info ""
    Log-Info "Admin Name:      $($script:adminName)"
    Log-Info "NSG Name:        $($script:nsgName)"
    Log-Info "Storage Account: $($script:storageAccountName)"
    Log-Info "Location:        $($Location)"
    Log-Info "Container:       $($script:containerName)"
    Log-Info "VM Name:         $($script:vmName)"
    Log-Info "VM FQDN:         $($script:vmFQDN)"
}

function Import-Dependencies {
    Log-Info "Checking for Azure CLI..."

    az --version

    if (-not $?) {
        Handle-Error "You must install the Azure CLI." -IsFatal
    }
}

function Deploy-Azure {  
    Deploy-ApplicationRegistration
    
    if ($SkipArm -eq $False) {
        Log-Info "Looking for resource group '$ResourceGroup'..."
        if ((az group exists --name $ResourceGroup) -eq $false) {
            Log-Info "Resource group not found. Creating..."
            az group create --name $ResourceGroup --location $Location --verbose
        }

        $armTemplateTempPath = Get-FileTempPath -OriginalPath $ArmTemplateFilePath -TempPath $TempPath
        $armTemplateParametersTempPath = Get-FileTempPath -OriginalPath $ArmTemplateParametersFilePath -TempPath $TempPath

        Log-Info "Validating ARM template..."
        if (-Not(az deployment group validate --parameters $armTemplateParametersTempPath --resource-group $ResourceGroup --template-file $armTemplateTempPath --verbose)) {
            throw "Invalid template!!"
            Break
        }

        Log-Info "Deploying ARM template..."
        az deployment group create -g $ResourceGroup --template-file $armTemplateTempPath --parameters $armTemplateParametersTempPath --verbose
        Log-Info "Deploying ARM template: Done."
    }
    else {
        Log-Warning "Skipping ARM deployment."
    }
}


function Add-AADForLinuxExtension {
    if ($SkipAADLoginExtension -eq $False) {

   
        $extensionType = "AADLoginForLinux"

        $armTemplateParametersTempPath = Get-FileTempPath -OriginalPath $ArmTemplateParametersFilePath -TempPath $TempPath

        Log-Info "Acquiring VM name from '$armTemplateParametersTempPath'..."

        $armTemplateParametersContents = (Get-Content -Path $armTemplateParametersTempPath | ConvertFrom-Json)

        $vmName = $armTemplateParametersContents.parameters.virtualMachine_name.value

        az vm extension set --publisher "Microsoft.Azure.ActiveDirectory.LinuxSSH" --name $extensionType --resource-group $ResourceGroup --vm-name $vmName
    }
    else {
        Log-Warning "Skipping Add-AADForLinuxExtension deployment."
        
    }
}

function AddCurrentUserTo-VMAdmin {

    [Diagnostics.CodeAnalysis.SuppressMessageAttribute("PSUseApprovedVerbs", "")]
    Param()

    if ($SkipAADLoginExtension -eq $False) {

        $roleName = "Virtual Machine Administrator Login"

        Log-Info "Looking for '$($script:vmName)' VM..."
    
        $vm = (az vm show --resource-group $ResourceGroup --name $script:vmName --query id -o tsv)
    
        Log-Info "Looking for role assignment to '$roleName'..."
    
        $roleAsssignment = az role assignment list --assignee $script:user.objectId --role $roleName --scope $vm | ConvertFrom-Json
    
        if ($null -eq $roleAsssignment -or $roleAsssignment.Length -eq 0) {
            Log-Info "Adding new role assignment to '$roleName'..."
    
            az role assignment create --assignee $script:user.objectId --role $roleName --scope $vm
    
        }
        else {
            Log-Info "Existing role assignment found."
        }

    }
    else {
        
        Log-Warning "Skipping AddCurrentUserTo-VMAdmin deployment."


        Log-Warning "Adding SSH Key to VM"

        az vm user update --resource-group $ResourceGroup --name  $script:vmName --username $script:adminName --ssh-key-value $script:sshPubKey --verbose


    }

}
function Deploy-ApplicationRegistration {
    Log-Info "Looking for application registration '$($script:applicationName)'..."

    $script:clientSecret = -join (Get-CryptoRandom -Min 33 -Max 126 -Exclude @(34,36,38,39,92,96) -Count 20 | ForEach-Object {[char]$_}) # Exclude characters ", $, &, ', \, and `

    $startDate = [DateTime]::UtcNow.AddDays(-2)
    $endDate = [DateTime]::UtcNow.AddYears(1)

    $appRegList = az ad app list --display-name $script:applicationName | ConvertFrom-Json

    if ($null -ne $appRegList -and $appRegList[0].Length -ne 0 ) {
        Log-Info "Application registration '$($script:applicationName)' already exists."
        $appReg = $appRegList[0]

        Log-Info "Updating application..."
    
        Log-Info "  Start Date: $startDate"
        Log-Info "  End Date:   $endDate"

        az ad app update --id  $appReg.appId `
                        --display-name $script:applicationName `
                        --reply-urls "https://$($script:vmFQDN):8000/hub/oauth_callback" `
                        --available-to-other-tenants $False `
                        --password "`"$script:clientSecret`"" `
                        --start-date $startDate `
                        --required-resource-accesses appmanifest.json `
                        --end-date $endDate | ConvertFrom-Json 
    } else {
        Log-Info "Creating application registration '$($script:applicationName)'..."

        $appReg = az ad app create --display-name $script:applicationName `
                                   --reply-urls "https://$($script:vmFQDN):8000/hub/oauth_callback" `
                                   --available-to-other-tenants $False `
                                   --password "`"$script:clientSecret`"" `
                                   --start-date $startDate `
                                   --required-resource-accesses appmanifest.json `
                                   --end-date $endDate | ConvertFrom-Json 
    }

    if($null -eq $appReg.objectId -or $null -eq $appReg.appId)
    {
        Start-Sleep -Seconds 5
        $appRegList = az ad app list --display-name $script:applicationName | ConvertFrom-Json
        $appReg = $appRegList[0]
    }

    $script:appObjectId = $appReg.objectId
    $script:clientId = $appReg.appId

    Log-Info "Application Object Id: $($script:appObjectId)"
    Log-Info "Application Client Id: $($script:clientId)"
}


function Get-CryptoRandom {
    Param (
        [int] $Min,
        [int] $Max,
        [System.Collections.ArrayList] $Exclude,
        [int] $Count = 1
    )

    $rng = [System.Security.Cryptography.RNGCryptoServiceProvider]::Create()
            
    if ($Max -eq $Min)
    {
        Handle-Error "You must specify a range of numbers." -IsFatal
    }

    $randArray = New-Object System.Collections.ArrayList

    $range = $Max - $Min + 1
    
    for ($i = 0; $i -lt $Count; $i++) {
        do {
            $bytes = New-Object byte[](4)
            
            $rng.GetBytes($bytes)    
            
            $random = [System.BitConverter]::ToUInt32($bytes, 0)
            $value = $Min + ($random % $range)
        } while ($null -eq $Exclude -or $Exclude -contains $value)
        
        $randArray.Add($value) > $null
    }

    return $randArray
}

function Get-SASToken {
    $keys = (az storage account keys list -g $ResourceGroup -n $script:storageAccountName) | ConvertFrom-Json
    $script:sasToken = $keys[0].Value
}
function Format-JHubUserName {
    Param (
        [string] $Name
    )

    return ($Name -replace "(\s|\(|\)|,|\.)").ToLowerInvariant()
}

function Execute-PostDeployScript {

    [Diagnostics.CodeAnalysis.SuppressMessageAttribute("PSUseApprovedVerbs", "")]
    Param()

    Log-Info "Executing post-deployment script on remote VM '$($script:vmName)'..."

    $initialJHubUserName = Format-JHubUserName -Name $script:user.DisplayName

    #workaouround for AAD external accounts in which the principal name is not in a valid format for role assignment
    if ($null -ne $script:user.UserPrincipalName) {
        if ($script:user.UserPrincipalName.IndexOf("#EXT#") -ge 0) {
            $script:user.UserPrincipalName = $script:user.UserPrincipalName.Substring(0,$script:user.UserPrincipalName.IndexOf('#EXT')).Replace("_","@")
        }
    }
    Log-Info "Username '$($script:user.UserPrincipalName)'"
    
    
    $parameters = @{
        "sourceRepo"=$SourceRepo;
        "storageAccountName"=$script:storageAccountName;
        "sasToken"=$script:sasToken;
        "containerName"=$script:containerName;
        "vmFQDN"=$script:vmFQDN;
        "clientId"=$script:clientId;
        "clientSecret"=$script:clientSecret;
        "tenantId"=$script:tenantId;
        "initialJHubUserName"=$initialJHubUserName;
        "initialUserUpn"=$script:user.UserPrincipalName;
        "initialUserOid"=$script:user.objectId;
        "skipCert"=$SkipCert.ToString().ToUpper();
    }
    Log-Info "clientSecret clientId"
    Log-Info "clientId: '$($script:clientId)'"
    Log-Info "clientSecret: '$($script:clientSecret)'"
    
    Process-TemplateFile -Path $ProtectedConfigFilePath -TempPath $TempPath -Parameters $parameters

    $protectedConfigTempFilePath = Get-FileTempPath -OriginalPath $ProtectedConfigFilePath -TempPath $TempPath

    $extensionPublisher = "Microsoft.Azure.Extensions"
    $extensionType = "CustomScript"
    
    Log-Info "Looking for existing post-deployment script execution..."
    if (az vm extension show -g $ResourceGroup --vm-name $script:vmName -n $extensionType --only-show-errors) {
        Log-Info "Post-deployment script already executed."
    }
    else {
        Log-Info "Setting extension in VM..."

        az vm extension set --name $extensionType --publisher $extensionPublisher --version "2.0" --vm-name $script:vmName --resource-group $ResourceGroup --protected-settings $protectedConfigTempFilePath --verbose
        Log-Info "Extension set in VM."

        Log-Info "Acquiring NSG named '$($script:nsgName)'..."
        $nsgRuleName = "LetsEncrypt"

        Log-Info "Looking for NSG rule named '$nsgRuleName'..."
        $nsgRule = (az network nsg show -g $ResourceGroup -n $script:nsgName --query "securityRules[?name=='$nsgRuleName']")

        if ($null -eq $nsgRule -or $nsgRule.Length -eq 0) {
            Log-Warning "Could not find NSG rule."
        }
        else {
            Log-Info "Removing NSG rule named '$nsgRuleName'..."
            az network nsg rule delete -g $ResourceGroup --nsg-name $script:nsgName -n $nsgRuleName

            Log-Info "NSG rule named '$nsgRuleName' removed."
        }
    }
}

function EncryptAllDisk {
    
    if ($EncrypDisk -eq $True) {
        Log-Info "Encrypting disks..."
        az vm encryption enable --disk-encryption-keyvault $script:keyvaultName --name $script:vmName --resource-group $ResourceGroup --volume-type $DiskEncryptionMode --verbose
        az vm encryption show --name $script:vmName --resource-group $ResourceGroup

    }
    else {
        Log-Warning "Skipping Disk encryption"
    }
}

function AddVMDiagnosticsExtensions {

    Log-Info "Adding VM Diagnostic Extension..."
    az vm extension set --resource-group $ResourceGroup --vm-name $script:vmName  --name DependencyAgentLinux --publisher Microsoft.Azure.Monitoring.DependencyAgent --version 9.5 --verbose

    Log-Info "Enable Ubuntu VM Diagnostics..."
    az deployment group create -g $ResourceGroup --template-file $script:vmLogsDiagArmLocation --parameters storageAccount_name="$script:storageAccountName" virtualMachine_name="$script:vmName" location=$Location --verbose    
}
function EnableActivityLogsDiag {
    az provider register --namespace 'microsoft.insights' --verbose  

    Log-Info "Enabling Resources Logs Diagnostics..."
    az network watcher configure -g "NetworkWatcherRG" -l $Location --enabled true --verbose
    az network watcher flow-log create --name "$($Prefix)$($Random)FlowLog" --resource-group $ResourceGroup --enabled true --nsg $script:nsgName --storage-account $script:storageAccountName --location $location --format JSON --log-version 2
    az deployment group create -g $ResourceGroup --template-file $script:resourceLogsDiagArmLocation --parameters location=$location dataFactoryName=$script:dataFactory settingNameSuffix=$Prefix workspaceId="$script:LogWorkspaceName" storageAccountId="$script:storageAccountName" storageName="$script:storageAccountName" keyVaultName="$script:keyvaultName" vnetName="$script:VNET" vmPIP="$script:PIP"  nsgName="$script:nsgName"  vmNICName="$script:vmNIC" --verbose

}
function Restart-VM {
    Log-Info "Attempting to restart VM '$($script:vmName)'..."
    az vm restart -g $ResourceGroup -n $script:vmName --verbose
    Log-Info "VM restarted successfully. Please wait a few moments before attempting to connect to the resource."
}
function Display-Summary {

    [Diagnostics.CodeAnalysis.SuppressMessageAttribute("PSUseApprovedVerbs", "")]
    Param()
    
    Write-Host ""
    Write-Host "You can connect via the following endpoints:"
    Write-Host ""
    Write-Host "     Connect With SSH Active Directory: ssh -l $($script:user.UserPrincipalName) $($script:vmFQDN)"
    Write-Host "     Connect With SSH Key: ssh $($script:adminName)@$($script:vmFQDN) -p 22 -i $($script:sshKeyPath)"
    Write-Host "     JupyterHub: https://$($script:vmFQDN):8000/"
    Write-Host ""
}

function Post-Deployment {

    [Diagnostics.CodeAnalysis.SuppressMessageAttribute("PSUseApprovedVerbs", "")]
    Param()

    Add-AADForLinuxExtension
    AddCurrentUserTo-VMAdmin
    Get-SASToken
    Execute-PostDeployScript
    Restart-VM
    
}

function Cleanup {
    if (Test-Path -Path $TempPath) {
        Remove-Item -Path $TempPath -Recurse -ErrorVariable IsError

        if ($null -ne $IsError.Exception) {
            Log-Error "Error: $($IsError.Exception.Message)"
            Log-Error "Could not cleanup $TempPath! You should delete this manually."
        }
    }
}

function Remove-ResourceGroup {
    $confirm = Read-Host -Prompt "This will completely remove the resource group '$ResourceGroup'. Type yes to confirm"

    if ([string]::Compare($confirm, "yes", $True) -ne 0) {
        Log-Warning "Aborting uninstall."

        exit
    }

    Log-Info "Removing resource group '$ResourceGroup'..."
    az group delete -n $ResourceGroup --verbose
    Log-Info "Resource group '$ResourceGroup' removed."
}

function Remove-ApplicationRegistration {
    Log-Info "Removing application registration '$($script:applicationName)'..."

    $appRegList = az ad app list --display-name $script:applicationName | ConvertFrom-Json

    if ($null -ne $appRegList -and $appRegList[0].Length -ne 0 ) {
        az ad app delete --id $appRegList[0].objectId
        Log-Info "Application registration '$($script:applicationName)' removed."
    }
    else
    {
        Log-Info "Application registration '$($script:applicationName)' doesn't exist."
    }
   
}
   
function Run-Deployment {

    [Diagnostics.CodeAnalysis.SuppressMessageAttribute("PSUseApprovedVerbs", "")]
    Param()

    Log-Info "Deploying resources..."

    Import-Dependencies
    Connect-Azure
    Process-ArmTemplates
    PreProcess-Azure
    Deploy-Azure
    Post-Deployment
    AddVMDiagnosticsExtensions
    EnableActivityLogsDiag
    EncryptAllDisk
    Cleanup
    Log-Info "Deployment completed."
    Display-Summary  
}

function Run-Uninstall {

    [Diagnostics.CodeAnalysis.SuppressMessageAttribute("PSUseApprovedVerbs", "")]
    Param()

    Log-Info "Uninstalling resources..."

    Connect-Azure
    Remove-ResourceGroup
    Remove-ApplicationRegistration
}

if ($Random -eq $null -or $Random -eq "") {
    if ($Uninstall) {
        Handle-Error -Message "You must specify the random unique identifier used for your environment!" -IsFatal
    }

    $Random = -join ((65..90) + (97..122) | Get-Random -Count 5 | ForEach-Object {[char]$_})
} elseif ($Random.Length -lt 3) {
    Handle-Error -Message "You must specify a random value of at least 3 characters." -IsFatal
}

if ($ResourceGroup -eq $null -or $ResourceGroup -eq "") {
    $ResourceGroup = "$Prefix-$Random-jhub"
}

$script:applicationName = "$Prefix-$Random-jhub-app"

if ($Uninstall) {
    Run-Uninstall
} else {
    Run-Deployment
}