# Introduction 
This repository provides the configuration and deployment scripts for various VM configurations.

# Getting Started
1.	[Software dependencies](#Software-dependencies)
2.	[Deployment & Configuration Guides](#Deployment-&-Configuration-Guides)

# Software Dependencies (**If not using the Azure Cloud Shell for the installation)
1. [PowerShell Core >=6.2.4](https://docs.microsoft.com/en-us/powershell/scripting/install/installing-powershell?view=powershell-7)
3. [Azure CLI >=2.0.77](https://docs.microsoft.com/en-us/cli/azure/install-azure-cli?view=azure-cli-latest)


# Deployment & Configuration Guide
|Name|Description|
|-|-|
|[Data Science Multi-User Environment](./docs/deployment-guide.md)|VM based on the DSVM image hosting JupyterHub spawning single-user Jupyter notebook processes for multiple users.|