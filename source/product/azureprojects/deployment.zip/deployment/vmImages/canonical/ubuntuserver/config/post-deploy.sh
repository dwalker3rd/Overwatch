#!/bin/bash
## Copyright (c) Microsoft Corporation. All rights reserved.
## Licensed under the MIT License.

# Fix expired GPG key for tensorflow and R
curl https://storage.googleapis.com/tensorflow-serving-apt/tensorflow-serving.release.pub.gpg | sudo apt-key add -
sudo apt-key adv --keyserver keyserver.ubuntu.com --recv-keys E298A3A825C0D65DFD57CBB651716619E084DAB9

# Update package indexes
sudo apt-get update
# Ensure intallation tools are installed
sudo apt-get install curl -y
sudo apt install dos2unix
# ensure git is installed
sudo apt-get install git -y

sudo unattended-upgrade -d

# Update package indexes
sudo apt-get update

# Create vmusers group (use for setting permissions for applicable users)
sudo addgroup vmusers --gid 4000


### Mount data disk (https://docs.microsoft.com/en-us/azure/virtual-machines/linux/attach-disk-portal) ###
disk_to_format=$(lsblk --fs --json | jq -r '.blockdevices[] | select(.children == null and .fstype == null) | .name' | grep "sd")

sudo mkdir -p /datadrive

if [ -z disk_to_format ]; then

    ### Mount DataDrive
    disk_to_mount=$(lsblk --json | jq -r '.blockdevices[] | select(.children != null and .children[0].mountpoint == null and .children[0].type=="part") | .name' | grep "sd")
    UUID_MOUNT=$(blkid -o value -s UUID /dev/${disk_to_mount}1)

    if [ -z "$(grep $UUID_MOUNT\ /datadrive /etc/fstab)" ]; then
        sudo echo "UUID=$(blkid -o value -s UUID /dev/${disk_to_mount}1) /datadrive   ext4   defaults,nofail   1   2"  >> /etc/fstab
    else
        echo "/etc/fstab was not modified. ${disk_to_mount}1 is already in fstab"
    fi
    
    sudo mount -a
 
else
    sudo parted --script /dev/$disk_to_format mklabel gpt mkpart primary ext4 0% 100%

    # Wait until format disk is done ###
    sleep 5
    
    sudo mkfs.ext4 /dev/${disk_to_format}1

    sudo partprobe /dev/${disk_to_format}1
    
    sudo lsblk -o NAME,HCTL,SIZE,MOUNTPOINT | grep -i "sd"
    
    sudo mount /dev/${disk_to_format}1 /datadrive
    
    sudo echo "UUID=$(blkid -o value -s UUID /dev/${disk_to_format}1) /datadrive   ext4   defaults,nofail   1   2"  >> /etc/fstab
fi

# Create blobfuse mount point and set permissions
sudo mkdir /datadrive/blobfusemnt
sudo mkdir -p /data/blobfuse
sudo chown root:vmusers /datadrive/blobfusemnt


sudo mkdir -p ~/post-deploy
cd ~/post-deploy
sudo curl -o config.zip "$PD_SOURCE_REPO"
sudo unzip -u config.zip -d multi-user-process-jhub
# copy files to destination locations
sudo cp -Rv ~/post-deploy/multi-user-process-jhub/etc/* /etc
sudo cp -Rv ~/post-deploy/multi-user-process-jhub/lib/* /lib
sudo cp -Rv ~/post-deploy/multi-user-process-jhub/usr/* /usr

# update configuration files
sudo sed -i "s/{storage_account_name}/"$PD_STORAGE_ACCOUNT_NAME"/g" /etc/blobfuse/configuration.cfg
sudo sed -i "s {SAS_token} "$PD_SAS_TOKEN" g" /etc/blobfuse/configuration.cfg
sudo sed -i "s/{container_name}/"$PD_CONTAINER_NAME"/g" /etc/blobfuse/configuration.cfg

sudo sed -i "s/{vm_fqdn}/"$PD_VM_FQDN"/g" /etc/jupyterhub/jupyterhub_config.py
sudo sed -i "s/{client_id}/"$PD_CLIENT_ID"/g" /etc/jupyterhub/jupyterhub_config.py
sudo sed -i "s {client_secret} "$PD_CLIENT_SECRET" g" /etc/jupyterhub/jupyterhub_config.py
sudo sed -i "s/{initialJHubUserName}/"$PD_INITIAL_JHUB_USER_NAME"/g" /etc/jupyterhub/jupyterhub_config.py

sudo sed -i "s/{tenant_id}/"$PD_TENANT_ID"/g" /lib/systemd/system/jupyterhub.service

# update scripts and permissions
sudo sed -i "s/{vm_fqdn}/"$PD_VM_FQDN"/g" /usr/bin/revoke-cert.sh

#check files unix format and permissions
sudo dos2unix /etc/blobfuse/configuration.cfg
sudo chown root:root /etc/blobfuse/configuration.cfg
sudo chmod 600 /etc/blobfuse/configuration.cfg

sudo chown root:root /etc/jupyterhub/jupyterhub_config.py
sudo chmod 600 /etc/jupyterhub/jupyterhub_config.py
sudo chown root:root /lib/systemd/system/jupyterhub.service
sudo chmod 600 /lib/systemd/system/jupyterhub.service

sudo chown root:root /usr/bin/revoke-cert.sh
sudo chmod 600 /usr/bin/revoke-cert.sh

sudo chown root:root /usr/bin/blobfuse-mount.sh
sudo chmod 700 /usr/bin/blobfuse-mount.sh

# install oauthenticator
sudo /data/anaconda/envs/py35/bin/pip install oauthenticator==0.12.0
sudo /data/anaconda/envs/py35/bin/pip install pyjwt==1.7.1

#mount storage
sudo sh /usr/bin/blobfuse-mount.sh /data/blobfuse fuse _netdev

# backup fstab
if [ -f "/etc/fstab.bak" ]; then
    sudo cp /etc/fstab.bak /etc/fstab
else
    sudo cp /etc/fstab /etc/fstab.bak
    sudo echo "/usr/bin/blobfuse-mount.sh /data/blobfuse fuse _netdev" >>/etc/fstab
fi

if [ -f "/etc/rc.local.bak" ]; then
    sudo cp /etc/rc.local.bak /etc/rc.local
else
    sudo cp /etc/rc.local /etc/rc.local.bak
    sudo sed -i -e '$i sh /usr/bin/blobfuse-mount.sh /data/blobfuse fuse _netdev' /etc/rc.local
fi

# install certbot
if [ "$PD_SKIP_CERT" = "TRUE" ]; then
    echo "Skipped acquiring Let's Encrypt SSL certificate via certbot."

    # generate ssl certificate (currently self-signed)
    sudo mkdir -p /etc/letsencrypt/live/$PD_VM_FQDN
    sudo openssl req -x509 -newkey rsa:4096 -subj "/C=US/ST=Washington/L=Redmond/O=Microsoft/OU=MS/CN=$PD_VM_FQDN" -nodes -keyout /etc/letsencrypt/live/$PD_VM_FQDN/privkey.pem -out /etc/letsencrypt/live/$PD_VM_FQDN/fullchain.pem -days 365
else
    sudo apt-get install software-properties-common -y
    sudo add-apt-repository universe -y
    sudo add-apt-repository ppa:certbot/certbot -y
    sudo apt-get update -y
    sudo apt-get install certbot -y

    # request certificate
    sudo certbot certonly --standalone --non-interactive --agree-tos --domains $PD_VM_FQDN --email $PD_INITIAL_USER_UPN
fi

# reload systemd
sudo systemctl daemon-reload